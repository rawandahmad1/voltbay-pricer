/**
 * ═══════════════════════════════════════════════════════════════
 *  VoltBay Smart Auto-Pricer  —  server.js
 *  Runs as a lightweight Node.js server (Railway / Render / VPS)
 *
 *  What it does:
 *  1. Listens for Shopify "product created" + "product updated" webhooks
 *  2. Reads the product's weight, type, and tags to classify its size
 *  3. Calculates the correct UK selling price so that after ALL fees
 *     (VAT 20%, Shopify fees, shipping, buffer) you always net £10
 *  4. Writes the final price back to every variant via the Admin API
 *  5. Exposes a /reprice endpoint to reprice ALL products at once
 *  6. Exposes a /dashboard endpoint to view current pricing logic
 * ═══════════════════════════════════════════════════════════════
 */

'use strict';

const http    = require('http');
const https   = require('https');
const crypto  = require('crypto');
const url     = require('url');

// ── Config (set these as environment variables on your server) ──────────
const CONFIG = {
  SHOPIFY_STORE:        process.env.SHOPIFY_STORE        || 'voltbay-premi.myshopify.com',
  SHOPIFY_TOKEN:        process.env.SHOPIFY_TOKEN        || '',   // Admin API token
  WEBHOOK_SECRET:       process.env.WEBHOOK_SECRET       || '',   // Webhook HMAC secret
  PORT:                 parseInt(process.env.PORT)       || 3000,

  // Your fixed net profit target (in GBP)
  NET_PROFIT:           parseFloat(process.env.NET_PROFIT || '10'),

  // Shopify plan fee structure
  // Change to 'basic' or 'advanced' if you upgrade/downgrade
  SHOPIFY_PLAN:         process.env.SHOPIFY_PLAN         || 'standard',

  // Safety buffer % — absorbs FX losses, partial refunds, rounding
  BUFFER_PCT:           parseFloat(process.env.BUFFER_PCT || '3'),
};

// ── Processor fee table ─────────────────────────────────────────────────
const PROCESSOR = {
  basic:    { pct: 0.029,  fixed: 0.30, extra: 0.020 },
  standard: { pct: 0.026,  fixed: 0.30, extra: 0.010 },
  advanced: { pct: 0.024,  fixed: 0.30, extra: 0.005 },
};

// ── Size classification ─────────────────────────────────────────────────
// Products are auto-classified by weight (grams) + product type keywords.
// You can also force a size by adding a tag: size:micro / size:small /
// size:medium / size:large / size:xlarge
const SIZE_RULES = [
  { size: 'micro',  maxWeight: 500,   keywords: ['cable','earbud','accessory','case','charger','adapter','watch','band','stylus','pen','controller'] },
  { size: 'small',  maxWeight: 1000,  keywords: ['phone','smartphone','tablet','headphone','speaker','thermostat','camera','powerbank','power bank','smartwatch','router'] },
  { size: 'medium', maxWeight: 3000,  keywords: ['laptop','console','gaming','printer','display','monitor','projector','vacuum','air fryer','cooker','appliance'] },
  { size: 'large',  maxWeight: 8000,  keywords: ['tv','television','washing','dishwasher','fridge','freezer','power station','desktop','workstation'] },
  { size: 'xlarge', maxWeight: 99999, keywords: ['oled','qled','large tv','big screen'] },
];

// ── Shipping costs (GBP) by size ────────────────────────────────────────
// These are AVERAGE UK-origin shipping costs you pay your courier.
// Adjust to match your actual DPD / Royal Mail / Hermes rates.
const SHIPPING = {
  micro:  3.50,
  small:  5.50,
  medium: 9.50,
  large:  18.00,
  xlarge: 42.00,
};

// ── VAT rate (UK) ───────────────────────────────────────────────────────
// You charge UK VAT on all sales from your UK store.
// For US/EU/other customers: Shopify handles their local tax at checkout
// on top of your price — you don't collect it, so we only build in UK VAT.
const VAT_RATE = 0.20;

// ════════════════════════════════════════════════════════════════
//  CORE PRICING ENGINE
// ════════════════════════════════════════════════════════════════

/**
 * Classify a product's size from its weight (grams), type string, and tags.
 * Tags take priority: add tag "size:large" to override auto-detection.
 */
function classifySize(weightGrams, productType, tags) {
  // Tag override first
  const tagList = (tags || '').toLowerCase();
  const typeStr = (productType || '').toLowerCase();

  for (const override of ['micro','small','medium','large','xlarge']) {
    if (tagList.includes('size:' + override)) return override;
  }

  // Weight-based + keyword matching
  const weight = weightGrams || 500; // default 500g if not set

  for (const rule of SIZE_RULES) {
    if (weight <= rule.maxWeight) {
      // Also check if product type matches any keyword for this tier
      const keywordMatch = rule.keywords.some(k =>
        typeStr.includes(k) || tagList.includes(k)
      );
      // Use weight tier, but bump up if keyword suggests heavier category
      if (keywordMatch || rule.size === 'micro') return rule.size;
    }
  }

  // Keyword scan across all tiers (catches cases where weight not set)
  for (const rule of SIZE_RULES) {
    if (rule.keywords.some(k => typeStr.includes(k) || tagList.includes(k))) {
      return rule.size;
    }
  }

  return 'small'; // safe default
}

/**
 * Calculate the final selling price (GBP) for a given cost price.
 * Uses iterative convergence because processor fees are % of final price.
 *
 * Formula per iteration:
 *   price = cost + shipping + profit + proc_fee(price) + shopify_fee(price)
 *           + vat(price) + buffer(price)
 *
 * Converges in 6–8 iterations to within 1p accuracy.
 */
function calculatePrice(costGBP, size, options = {}) {
  const shipping  = SHIPPING[size] || SHIPPING.small;
  const proc      = PROCESSOR[CONFIG.SHOPIFY_PLAN] || PROCESSOR.standard;
  const profit    = options.profit  ?? CONFIG.NET_PROFIT;
  const bufPct    = (options.buffer ?? CONFIG.BUFFER_PCT) / 100;

  let price = costGBP + shipping + profit; // starting estimate

  for (let i = 0; i < 10; i++) {
    const procFee    = price * proc.pct + proc.fixed;
    const shopifyFee = price * proc.extra;
    const vat        = price * VAT_RATE;
    const buffer     = price * bufPct;
    price = costGBP + shipping + profit + procFee + shopifyFee + vat + buffer;
  }

  // Round up to nearest £0.99 (psychological pricing) or plain 2dp
  return Math.ceil(price * 100) / 100;
}

/**
 * Full breakdown of a price for logging / dashboard.
 */
function priceBreakdown(costGBP, size, finalPrice, options = {}) {
  const shipping   = SHIPPING[size] || SHIPPING.small;
  const proc       = PROCESSOR[CONFIG.SHOPIFY_PLAN] || PROCESSOR.standard;
  const profit     = options.profit ?? CONFIG.NET_PROFIT;
  const bufPct     = (options.buffer ?? CONFIG.BUFFER_PCT) / 100;
  const procFee    = finalPrice * proc.pct + proc.fixed;
  const shopifyFee = finalPrice * proc.extra;
  const vat        = finalPrice * VAT_RATE;
  const buffer     = finalPrice * bufPct;

  return {
    costPrice:    costGBP.toFixed(2),
    shipping:     shipping.toFixed(2),
    processorFee: procFee.toFixed(2),
    shopifyFee:   shopifyFee.toFixed(2),
    vatCollected: vat.toFixed(2),
    buffer:       buffer.toFixed(2),
    netProfit:    profit.toFixed(2),
    finalPrice:   finalPrice.toFixed(2),
    size,
  };
}

// ════════════════════════════════════════════════════════════════
//  SHOPIFY API HELPERS
// ════════════════════════════════════════════════════════════════

function shopifyRequest(method, path, body) {
  return new Promise((resolve, reject) => {
    const payload = body ? JSON.stringify(body) : null;
    const options = {
      hostname: CONFIG.SHOPIFY_STORE,
      path:     '/admin/api/2024-01' + path,
      method,
      headers: {
        'X-Shopify-Access-Token': CONFIG.SHOPIFY_TOKEN,
        'Content-Type': 'application/json',
        'Accept':       'application/json',
        ...(payload ? { 'Content-Length': Buffer.byteLength(payload) } : {}),
      },
    };

    const req = https.request(options, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch (e) { resolve({ status: res.statusCode, body: data }); }
      });
    });

    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

/**
 * Update a single variant's price in Shopify.
 */
async function setVariantPrice(variantId, price) {
  const res = await shopifyRequest('PUT', `/variants/${variantId}.json`, {
    variant: { id: variantId, price: price.toFixed(2) }
  });
  return res;
}

/**
 * Get all products (paginated).
 */
async function getAllProducts() {
  const products = [];
  let link = '/products.json?limit=250&fields=id,title,product_type,tags,variants,options';

  while (link) {
    const res = await shopifyRequest('GET', link);
    if (res.body.products) products.push(...res.body.products);

    // Parse Link header for pagination
    link = null; // Shopify cursor-based pagination handled via page_info
  }

  return products;
}

// ════════════════════════════════════════════════════════════════
//  PRODUCT PRICING LOGIC
// ════════════════════════════════════════════════════════════════

/**
 * Auto-price all variants of a product.
 * Called when a product is created or updated via webhook.
 *
 * Cost price detection order:
 *  1. Variant metafield: voltbay.cost_price  (most accurate)
 *  2. compare_at_price * 0.65  (if set — implies RRP, assume 35% margin)
 *  3. current price * 0.60     (fallback — assume 40% margin)
 *
 * Add a metafield "voltbay / cost_price" to any product to set exact cost.
 */
async function autoPriceProduct(product) {
  const results = [];
  const size = classifySize(
    product.variants?.[0]?.weight || 0,
    product.product_type,
    product.tags
  );

  for (const variant of (product.variants || [])) {
    const currentPrice  = parseFloat(variant.price) || 0;
    const compareAt     = parseFloat(variant.compare_at_price) || 0;

    // Cost price estimation
    let costGBP;
    if (variant.cost) {
      // Shopify inventory cost (set in admin)
      costGBP = parseFloat(variant.cost);
    } else if (compareAt > currentPrice) {
      // Has a sale — use compare_at * 0.65 as cost estimate
      costGBP = compareAt * 0.65;
    } else {
      // No cost data — assume current price is roughly 60% above cost
      costGBP = currentPrice * 0.60;
    }

    // Convert USD prices to GBP (your store prices in USD currently)
    // Using approximate rate — set USD_TO_GBP env var for live rate
    const usdToGbp = parseFloat(process.env.USD_TO_GBP || '0.79');
    costGBP = costGBP * usdToGbp;

    const finalPrice = calculatePrice(costGBP, size);
    const bd = priceBreakdown(costGBP, size, finalPrice);

    console.log(`[PRICE] ${product.title} / ${variant.title}`);
    console.log(`  Size: ${size} | Cost: £${costGBP.toFixed(2)} | Final: £${finalPrice.toFixed(2)}`);
    console.log(`  Breakdown:`, bd);

    if (CONFIG.SHOPIFY_TOKEN) {
      await setVariantPrice(variant.id, finalPrice);
      console.log(`  ✓ Updated variant ${variant.id} to £${finalPrice.toFixed(2)}`);
    } else {
      console.log(`  ⚠ No SHOPIFY_TOKEN set — dry run only`);
    }

    results.push({ variantId: variant.id, title: variant.title, finalPrice, breakdown: bd });

    // Respect Shopify API rate limit (2 req/s on basic, 4/s on standard)
    await new Promise(r => setTimeout(r, 300));
  }

  return { product: product.title, size, variants: results };
}

// ════════════════════════════════════════════════════════════════
//  WEBHOOK VERIFICATION
// ════════════════════════════════════════════════════════════════

function verifyWebhook(body, hmacHeader) {
  if (!CONFIG.WEBHOOK_SECRET) return true; // skip if not configured
  const hash = crypto
    .createHmac('sha256', CONFIG.WEBHOOK_SECRET)
    .update(body, 'utf8')
    .digest('base64');
  return hash === hmacHeader;
}

// ════════════════════════════════════════════════════════════════
//  HTTP SERVER
// ════════════════════════════════════════════════════════════════

const server = http.createServer(async (req, res) => {
  const parsed = url.parse(req.url, true);
  const path   = parsed.pathname;

  // ── Health check ──
  if (req.method === 'GET' && path === '/') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      status:  'VoltBay Auto-Pricer running',
      plan:    CONFIG.SHOPIFY_PLAN,
      profit:  `£${CONFIG.NET_PROFIT}`,
      buffer:  `${CONFIG.BUFFER_PCT}%`,
      vatRate: `${VAT_RATE * 100}%`,
    }));
    return;
  }

  // ── Dashboard ──
  if (req.method === 'GET' && path === '/dashboard') {
    const examples = ['micro','small','medium','large','xlarge'].map(size => {
      const costs = { micro:10, small:50, medium:150, large:400, xlarge:1000 };
      const cost  = costs[size];
      const price = calculatePrice(cost, size);
      return { size, cost, ...priceBreakdown(cost, size, price) };
    });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ config: CONFIG, examples }, null, 2));
    return;
  }

  // ── Manual reprice all products ──
  if (req.method === 'POST' && path === '/reprice') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.write(JSON.stringify({ status: 'started', message: 'Repricing all products...' }) + '\n');

    try {
      const products = await getAllProducts();
      const results  = [];
      for (const product of products) {
        const result = await autoPriceProduct(product);
        results.push(result);
        await new Promise(r => setTimeout(r, 500));
      }
      res.end(JSON.stringify({ status: 'done', updated: results.length, results }));
    } catch (e) {
      res.end(JSON.stringify({ status: 'error', message: e.message }));
    }
    return;
  }

  // ── Shopify Webhook: products/create + products/update ──
  if (req.method === 'POST' && (path === '/webhook/product-create' || path === '/webhook/product-update')) {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', async () => {
      const hmac = req.headers['x-shopify-hmac-sha256'];
      if (!verifyWebhook(body, hmac)) {
        res.writeHead(401);
        res.end('Unauthorized');
        return;
      }

      // Respond immediately (Shopify requires < 5s response)
      res.writeHead(200);
      res.end('OK');

      // Process async
      try {
        const product = JSON.parse(body);
        console.log(`[WEBHOOK] Product ${path.includes('create') ? 'created' : 'updated'}: ${product.title}`);
        const result = await autoPriceProduct(product);
        console.log('[WEBHOOK] Done:', JSON.stringify(result, null, 2));
      } catch (e) {
        console.error('[WEBHOOK] Error:', e.message);
      }
    });
    return;
  }

  // ── Price calculator endpoint (test a specific cost + size) ──
  if (req.method === 'GET' && path === '/calculate') {
    const cost  = parseFloat(parsed.query.cost)  || 100;
    const size  = parsed.query.size || 'small';
    const price = calculatePrice(cost, size);
    const bd    = priceBreakdown(cost, size, price);
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ input: { cost, size }, ...bd }));
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(CONFIG.PORT, () => {
  console.log(`
╔══════════════════════════════════════════════════════╗
║       VoltBay Smart Auto-Pricer  —  RUNNING          ║
╠══════════════════════════════════════════════════════╣
║  Port:      ${CONFIG.PORT}                                    ║
║  Store:     ${CONFIG.SHOPIFY_STORE.substring(0,30).padEnd(30)}  ║
║  Plan:      Shopify ${CONFIG.SHOPIFY_PLAN.padEnd(20)}         ║
║  Profit:    £${String(CONFIG.NET_PROFIT).padEnd(10)} net per sale            ║
║  VAT:       20% (UK)                                 ║
║  Buffer:    ${CONFIG.BUFFER_PCT}%                                    ║
╠══════════════════════════════════════════════════════╣
║  POST /webhook/product-create  → auto-price on add   ║
║  POST /webhook/product-update  → auto-price on edit  ║
║  POST /reprice                 → reprice ALL now      ║
║  GET  /calculate?cost=X&size=Y → test the engine     ║
║  GET  /dashboard               → view config + rules  ║
╚══════════════════════════════════════════════════════╝
  `);
});

module.exports = { calculatePrice, classifySize, priceBreakdown };
