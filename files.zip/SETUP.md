# VoltBay Auto-Pricer — Setup Guide
## From zero to automatic pricing in 20 minutes

---

## How it works

Every time you add or edit a product in Shopify, this server:

1. Receives a webhook notification from Shopify instantly
2. Reads the product's weight, type, and tags to figure out its size (micro/small/medium/large/XL)
3. Estimates your cost price from Shopify's inventory cost field (or compare_at_price, or current price)
4. Runs the pricing formula:

```
Final Price = Cost + Shipping + Your £10 Profit
              + Shopify Fees (on final price)
              + VAT 20% (on final price)
              + 3% Safety Buffer (on final price)
```

5. Writes the calculated price back to every variant automatically

---

## Step 1 — Get your Shopify Admin API token

1. Go to **Shopify Admin → Settings → Apps and sales channels**
2. Click **Develop apps** → **Create an app**
3. Name it "VoltBay Auto-Pricer"
4. Click **Configure Admin API scopes**
5. Enable: `write_products`, `read_products`, `read_inventory`
6. Click **Save** → **Install app**
7. Copy the **Admin API access token** (starts with `shpat_`)
   ⚠️ You only see it once — copy it now

---

## Step 2 — Deploy to Railway (free)

Railway gives you a free server that runs 24/7.

1. Go to **https://railway.app** → Sign up with GitHub
2. Click **New Project → Deploy from GitHub repo**
3. Upload this folder as a GitHub repo:
   - Go to **github.com** → New repository → name it `voltbay-pricer`
   - Upload all files from this folder
   - Come back to Railway and connect the repo
4. Railway will detect Node.js and deploy automatically
5. Once deployed, you'll get a URL like:
   `https://voltbay-pricer-production.up.railway.app`

**Set environment variables in Railway:**
Click your service → Variables → Add these:
```
SHOPIFY_STORE    = voltbay-premi.myshopify.com
SHOPIFY_TOKEN    = shpat_your_token_here
WEBHOOK_SECRET   = (get this in Step 3)
SHOPIFY_PLAN     = standard
NET_PROFIT       = 10
BUFFER_PCT       = 3
USD_TO_GBP       = 0.79
PORT             = 3000
```

---

## Step 3 — Register Shopify webhooks

1. Go to **Shopify Admin → Settings → Notifications → Webhooks**
2. Click **Create webhook** — do this TWICE:

**Webhook 1 — new products:**
- Event: **Product creation**
- Format: JSON
- URL: `https://your-railway-url.up.railway.app/webhook/product-create`
- API version: 2024-01

**Webhook 2 — product updates:**
- Event: **Product update**
- Format: JSON
- URL: `https://your-railway-url.up.railway.app/webhook/product-update`
- API version: 2024-01

3. After creating the first webhook, Shopify shows you a **signing secret**
   Copy it → paste as `WEBHOOK_SECRET` in Railway environment variables

---

## Step 4 — Set cost prices on your products (important!)

The auto-pricer needs to know what you paid for each product.
The most accurate way: set the **Cost per item** in Shopify.

1. Open any product → scroll to **Inventory** section
2. Find **Cost per item** → enter your wholesale cost in USD
3. Save the product → the webhook fires → price is set automatically

If you don't set a cost price, the system estimates it from the current price.

---

## Step 5 — Reprice all existing products now

Hit this URL once to reprice everything you already have:

```
POST https://your-railway-url.up.railway.app/reprice
```

Or open a terminal and run:
```bash
curl -X POST https://your-railway-url.up.railway.app/reprice
```

---

## Step 6 — Tag products to control size classification

The system auto-detects size from product type and weight.
To override, add a tag to any product:

| Tag | Shipping cost | Example products |
|---|---|---|
| `size:micro` | £3.50 | Cables, earbuds, cases, bands |
| `size:small` | £5.50 | Phones, headphones, watches |
| `size:medium` | £9.50 | Tablets, consoles, laptops |
| `size:large` | £18.00 | Large laptops, printers, vacuums |
| `size:xlarge` | £42.00 | TVs, large appliances |

---

## Test the pricing engine

Test any cost + size combination:
```
GET https://your-railway-url.up.railway.app/calculate?cost=100&size=small
```

Response:
```json
{
  "costPrice": "79.00",
  "shipping": "5.50",
  "processorFee": "8.22",
  "shopifyFee": "3.16",
  "vatCollected": "39.18",
  "buffer": "5.88",
  "netProfit": "10.00",
  "finalPrice": "151.02",
  "size": "small"
}
```

---

## Adjust shipping rates

Edit `server.js` line ~68 to match your actual courier costs:

```js
const SHIPPING = {
  micro:  3.50,   // Royal Mail 2nd class small parcel
  small:  5.50,   // Royal Mail 1st class / DPD standard
  medium: 9.50,   // DPD next-day
  large:  18.00,  // DPD large parcel
  xlarge: 42.00,  // Freight / XL courier
};
```

---

## About tax for international customers

You asked about customers from the US, EU, and worldwide.
Here's how Shopify handles it:

| Customer | Tax handling |
|---|---|
| 🇬🇧 UK | You collect 20% VAT — built into price |
| 🇺🇸 US | Shopify Tax collects US state sales tax at checkout ON TOP of your price. You keep your full price. |
| 🇪🇺 EU | Shopify collects EU VAT at checkout (via Import One-Stop Shop). You keep your full price. |
| 🇦🇪 UAE | 5% VAT collected at checkout by Shopify |
| 🌍 Other | Shopify collects at checkout based on their country |

So the auto-pricer only builds UK VAT into your base price.
For all other countries, Shopify adds their local tax on top automatically — you always receive your £10 profit regardless of where the customer is.

**Enable this in Shopify:**
Settings → Taxes and duties → Enable "Collect VAT/tax" for each region.

---

## Monitoring

View live pricing config:
```
GET https://your-railway-url.up.railway.app/dashboard
```

Railway also shows real-time logs — you'll see every product priced:
```
[WEBHOOK] Product created: Sony WH-1000XM5
[PRICE] Sony WH-1000XM5 / Midnight Black
  Size: medium | Cost: £181.70 | Final: £348.22
  ✓ Updated variant 53799208223038 to £348.22
```
